from app import start_play, welcome

welcome()
start_play()
